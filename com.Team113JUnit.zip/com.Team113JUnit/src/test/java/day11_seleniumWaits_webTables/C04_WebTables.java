package day11_seleniumWaits_webTables;

public class C04_WebTables {
    /*
    html kodlariyla olusturullmus excel e benzeyen satirlar
    ve satirlardaki datalardan olusan yapidir.
    Front end developerlar web tablolarini farkli kod bloklari ile
    olusturabilirler ama html nin temelinde webtable olusturmak icin
    kullanilan yapi su sekildedir
    table
        thead
            tr
                td
        tbody
            tr
                td

                web table larda locate islemi icin absolute.xpath e benzer bir
                sekilde

                //table/tbody/tr/td sirlamasi ile locate yapariz
                tr ve td icin [index] kullanilabilir
     */
}
